@echo off
setlocal
cd /d "%~dp0"
echo ===========================================================
echo CAREBRIDGE - Production deployment to Vercel
 echo Please use a computer with internet and Node.js 20+
echo ===========================================================
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js is missing. Install it from https://nodejs.org/
  pause
  exit /b 1
)
echo.
echo First you may be asked to log in to Vercel.
echo For project directory choose .\ (this extracted root folder).
echo.
call npx --yes vercel@latest --prod
if errorlevel 1 (
  echo Deployment did not finish. See VERCEL_DEPLOYMENT.md.
) else (
  echo A production URL should be shown above. Test it on your phone.
)
pause
endlocal
