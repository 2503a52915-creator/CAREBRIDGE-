# CAREBRIDGE — Connected Care Continuity Platform

**Tagline:** Connect care. Close gaps. Support better journeys.

A responsive educational full-stack healthcare coordination application using React 19, TypeScript, Vite, Tailwind CSS, Lucide, Recharts, React Router, Supabase, PostgreSQL, Supabase Authentication, Realtime and private Supabase Storage. The backend is hosted by Supabase (Postgres, RLS, triggers, Storage and one Edge Function), **not a separate Express server**. The `frontend/`, `backend/` and `database/` source folders are intentionally separate.

## 🌐 Vercel production deployment and phone access (14 Nov–4 Dec 2026)

For a shareable link, follow **[VERCEL_DEPLOYMENT.md](VERCEL_DEPLOYMENT.md)** or double-click **DEPLOY_TO_VERCEL_WINDOWS.bat** on a Windows laptop with internet access. The root `vercel.json` builds the frontend workspace and publishes `frontend/dist`; it includes React Router SPA rewrites. A deployed app is accessible on mobile browsers over HTTPS. The teacher should receive the **production** Vercel URL, not `localhost`.

**Important:** Deployment has to be completed in an authenticated Vercel account before a real link exists. Browser-demo records are per-device until Supabase is connected; the 20-day public uptime is not guaranteed by Vercel's free plan.

## ⚡ Start locally on Windows, macOS or Linux (no cloud setup required)

Requirements: **Node.js 20+** and npm. This package intentionally excludes `node_modules`.

1. Extract `CAREBRIDGE_Vercel_Ready.zip` to any folder.
2. Open a terminal in the extracted `CAREBRIDGE` folder (the folder containing `package.json`).
3. Run:

   ```bash
   npm install
   npm run dev
   ```

4. Open **http://localhost:5173** in your browser.
5. Choose **Patient**, **Doctor**, **Admin** or **Donor** on the sign-in screen. These are fictional role buttons and **do not require passwords** in local demo mode.
6. `Ctrl+C` stops the development server. Run `npm run dev` to return to the project later.

On Windows, you can alternatively double-click `START_CAREBRIDGE.bat`. If PowerShell blocks `npm`, use `npm.cmd install` and `npm.cmd run dev` in Command Prompt.

### Demo data, storage, roles

`frontend/src/services/seed.ts` creates fictional users and connected sample records; the first load copies these into **browser localStorage**. Changes persist after refresh and are shared among roles in that browser. Role switching is available in the top-right menu. It is **NOT secure authentication or network/cloud realtime**. Two tabs of the same browser share localStorage updates via a `storage` listener (and changes in a tab update immediately). Never enter actual health records in demo mode.

| Role | Fictional profile | Examples |
|---|---|---|
| Patient | Maya Shah | Book appointments, upload sample records, make a blood request, view timeline, order demonstration products, revoke consent |
| Doctor | Dr. Arjun Mehta | Manage consent-authorized patient, create prescriptions, request investigations, add results, set follow-ups |
| Admin | CareBridge Admin | View user registry, activity charts, change order status, inspect audit events |
| Donor | Riya Kumar | View exact blood-group-and-city matches, accept demo requests, set availability, log activities |

The second sample doctor, Dr. Kavya Rao, does **not** have access to Maya's record unless a patient grants consent.

## 📁 Project layout

```text
CAREBRIDGE/
├── frontend/                       # ONLY React frontend and browser services
│   ├── src/
│   │   ├── pages/                   # Landing, auth, protected role pages, QR verification
│   │   ├── components/              # Sidebar, cards, forms, reusable UI
│   │   ├── context/                 # Session, actions, authorization and notifications
│   │   ├── services/                # Demo and Supabase repository adapters, seed data
│   │   ├── types/                   # Shared TypeScript domain types
│   │   └── utils/                   # Care-gap rules, journey timeline, translations
│   ├── .env.example
│   ├── vercel.json
│   └── package.json
├── backend/                        # ONLY cloud backend configuration/functions
│   ├── supabase/config.toml
│   └── supabase/functions/emergency-access/index.ts
│   └── README.md
├── database/                       # ONLY database migration files
│   └── migrations/001_schema.sql
├── tests/                          # Offline syntax/schema check
├── START_CAREBRIDGE.bat
├── package.json
└── README.md
```

## ☁️ Enable real Supabase cloud mode

Local demo requires **no database**. To use real persistent multi-user cloud data:

1. Create a Supabase project: https://supabase.com/dashboard. Keep the project isolated; use fictional data only.
2. In the Supabase **SQL Editor**, execute **all** of `database/migrations/001_schema.sql` in a new project. It sets up 26+ tables, basic indices, role functions, RLS policies, auth user profile creation, audit/notification triggers, medicine-history synchronization and a private Storage bucket. The schema is intended for a fresh project; do not rerun policies on the same project without a reset/migration strategy.
3. Copy `frontend/.env.example` to `frontend/.env` and fill in:

   ```dotenv
   VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLIC_OR_ANON_KEY
   VITE_FORCE_DEMO=false
   ```

   **NEVER put a service-role key or database password in VITE_ variables.** Vite variables are visible to browser users.
4. In Supabase Authentication, enable email/password sign-in; set email confirmation and auth redirect URLs for your app.
5. Register a *patient* and a *donor* using the app. Privileged doctor/admin roles are **not self-registerable**. To provision a doctor, create a user in Supabase Authentication using a secure admin workflow, then (as a trusted database administrator in SQL Editor) run:

   ```sql
   UPDATE public.users SET role='doctor', specialty='General Medicine'
   WHERE id='REPLACE-WITH-REAL-AUTH-USER-UUID';
   ```

   Admin provisioning is analogous (`role='admin'`). Use only trusted people for these roles; this example is not an invite automation.
6. Patient grants the doctor consent in the **Privacy Center**. The doctor can then see their record and create connected clinical demo entries.
7. Deploy the emergency function using Supabase CLI (see `backend/README.md`):

   ```bash
   cd backend
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase functions deploy emergency-access --no-verify-jwt
   supabase secrets set CAREBRIDGE_ALLOWED_ORIGIN=https://YOUR-APP-DOMAIN
   cd ..
   ```

   Set `CAREBRIDGE_ALLOWED_ORIGIN` to the **exact deployed frontend origin**; for local testing use `http://localhost:5173`. This endpoint uses a server-side service role key managed by Supabase, checks origin, token, PIN, expiry and number of attempts. QR tokens do not expose full medical records. A public endpoint is necessary for non-signed-in emergency verification; an external security audit is required before any real use.
8. Restart the Vite development server after changing `.env`. When Supabase credentials exist, the app switches to **Supabase cloud mode**. Use the real email/password registration and login options.
9. In Supabase, check the tables in Database > Tables and the publication in Database > Replication. Supabase Realtime sends changes across authorized sessions through its Postgres-change channels; this requires the configured project and network connectivity. Enable only the tables needed in production.

**Note:** The fictional five-person seed exists *only* in local demo. The Supabase SQL migration seeds four fictional catalog products, but does not create fake users or hardcoded passwords in live Auth. Accounts must be registered/provisioned as above.

## 📦 Production build and deployment

From the ZIP root:

```bash
npm install
npm run lint
npm run test
npm run build
```

Built static site is in **`frontend/dist/`**. Deploy `frontend/` on Vercel, Netlify or another static host that supports SPA fallback. Add the three Vite environment variables in the host's environment settings, then **rebuild**. Configure a rewrite of all non-asset routes to `/index.html`. `frontend/vercel.json` and `frontend/public/_redirects` are included. Deploy the **backend** and migration to Supabase separately. The client works in standalone demo mode if no environment values are provided; this is a demonstration, NOT multi-user production storage.

## 🔗 Connected workflow demonstrations

**1. Appointment → doctor:** Sign in as Patient, book an appointment with Arjun, switch to Doctor, view Appointments.

**2. Prescription → patient:** In Doctor > Prescriptions, add a fictional prescription for the consent-authorized patient. Switch to Patient > Prescriptions and Notifications.

**3. Investigation → care gaps:** Doctor > Investigations > Request investigation. Switch to Patient > Health Journey and Care Gaps. Return to Doctor, add a result, and see the pending administrative gap disappear.

**4. Follow-up → notification:** Doctor > Follow-ups, set a date; patient receives a notification.

**5. Pharmacy → order history:** Patient > Pharmacy, choose demonstration products, place an order, view Medicine History. As Admin > Pharmacy Orders, advance the status to `shipped` and `delivered`; return to patient to see updates.

**6. Blood help → donor:** Patient > Blood Help, create an `O+` request in `Warangal`, then switch to Donor > Matching Requests and accept it. The patient's request status and donor history update.

**7. Privacy / consent:** Patient > Privacy Center, revoke treatment consent, then switch to Doctor > My Patients to confirm that patient no longer appears.

**8. Emergency QR:** Patient > Emergency QR, create a 15-minute token + six-digit PIN. Open the QR link in the *same browser* for local demo or via the configured Supabase endpoint in cloud mode. Enter the PIN for a minimum-necessary summary. Revoke it and test again.

## 🧪 Test instructions and recorded environment status

```bash
npm run lint                # TypeScript type-check (requires dependency install)
npm run test                # Vitest: care gaps, authorized access, timeline, summary
npm run build               # TypeScript + Vite production compilation
node tests/offline_quality_check.cjs
```

**Verified in packaging environment:** offline TypeScript/TSX syntax parse and SQL table/dependency file presence checks completed successfully. **Not verified here:** `npm install`, `npm run lint`, `npm run test`, `npm run build`, browser clicks, Supabase API connections, true 2-session cloud Realtime, responsive browser rendering or unauthorized access penetration testing. The environment couldn't resolve `registry.npmjs.org`, so package installation timed out. These need to be run on a computer with npm access before calling this a production-ready deployment.

## 🧩 Included implementation and known limitations

- **Implemented as source:** Responsive landing/auth, protected role navigation, browser-persistent fictional dataset, patient/doctor/admin/donor dashboards, appointment forms, patient 360, consultation notes, call demo interface, prescriptions, investigations and completed results, derived care gaps, care plans, follow-ups, medical records and optional files, pharmacy/cart/orders/history, blood requests/matches, organ pledges/requests, family contacts, emergency summary/QR, notifications, privacy consent, audit records, analytics, English/Hindi/Telugu navigation labels, easy-access switch, browser speech synthesis and optional voice capture, deterministic record summary. Supabase-backed repository and database schema are provided as cloud integration source.
- **Not integrated:** real telemedicine voice/video/chat provider, payment and pharmacy fulfillment gateway, live hospital/blood-bank/organ-registry integrations, an AI diagnostic or LLM API. All such screens are explicitly demo-only.
- **Incomplete for production healthcare use:** Full interface translation beyond core navigation, independent authenticated family accounts, medical standards/interoperability, clinical validation, hardening RLS and RPC against every possible field mutation, transactional stock/appointment availability enforcement, high-assurance emergency identity verification, operational backup and incident response, and formal legal/regulatory compliance.
- **Local demo limitation:** Browser localStorage is unencrypted, role switching is unrestricted, demo calls are not actual calls, file uploads are browser-local and capped at 1 MB, token verification is browser-local, and cross-device sync does not exist. Do not use for confidential data.

If any cloud permissions fail after setup, inspect the browser console and Supabase logs. Do not disable RLS or use a service-role key in your frontend to work around access problems.

**Educational software only. Not a medical device, medical advice or certified healthcare platform.**
