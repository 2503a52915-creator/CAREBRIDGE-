/** @type {import('tailwindcss').Config} */
export default {content: ['./index.html','./src/**/*.{ts,tsx}'], theme: {extend: {fontFamily: {sans: ['Inter','ui-sans-serif','system-ui']}, colors: {navy: '#122d45', teal: '#087e89', mist: '#e9f6f6'}, boxShadow: {soft: '0 14px 42px rgba(20,49,75,.08)'}}}, plugins: []}
