import {Navigate,Route,Routes,useParams} from 'react-router-dom'
import {Loading} from './components/UI'
import {AppLayout,NAV} from './components/Navigation'
import {useApp} from './context/AppContext'
import {Landing,Auth,EmergencyVerify} from './pages/Public'
import {WorkspacePage} from './pages/Workspace'
function Workspace(){const {user,loading}=useApp();const {page='dashboard'}=useParams();if(loading)return <Loading/>;if(!user)return <Navigate to="/auth" replace/>;const slug=(NAV[user.role].some(x=>x.slug===page)||(user.role==='doctor'&&page==='patient-360'))?page:'dashboard';return <AppLayout page={slug}><WorkspacePage slug={slug}/></AppLayout>}
export default function App(){return <Routes><Route path="/" element={<Landing/>}/><Route path="/auth" element={<Auth/>}/><Route path="/emergency/:token" element={<EmergencyVerify/>}/><Route path="/app" element={<Navigate to="/app/dashboard" replace/>}/><Route path="/app/:page" element={<Workspace/>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes>}
