import {createClient, type SupabaseClient} from '@supabase/supabase-js'
import type {AppData, EntityKey, ItemOf, Repository, User} from '../types'
import {seedData} from './seed'

export const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim()
export const supabaseKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim()
export const cloudEnabled = Boolean(supabaseUrl && supabaseKey && import.meta.env.VITE_FORCE_DEMO !== 'true')
export const supabase: SupabaseClient | null = cloudEnabled ? createClient(supabaseUrl,supabaseKey,{auth:{persistSession:true,autoRefreshToken:true}}) : null
const STORE='carebridge-demo-v2'
const evt='carebridge-update'
export const ALL_KEYS:EntityKey[]=['users','appointments','consultations','prescriptions','labReports','carePlans','followUps','medicalRecords','bloodRequests','organDonors','organRequests','pharmacyProducts','orders','medicineHistory','notifications','consents','auditLogs','familyMembers','emergencyProfiles','emergencyTokens','donationHistory']
export const TABLES:Record<EntityKey,string>={users:'users',appointments:'appointments',consultations:'consultations',prescriptions:'prescriptions',labReports:'lab_reports',carePlans:'care_plans',followUps:'follow_ups',medicalRecords:'medical_records',bloodRequests:'blood_requests',organDonors:'organ_donors',organRequests:'organ_requests',pharmacyProducts:'pharmacy_products',orders:'medicine_orders',medicineHistory:'medicine_history',notifications:'notifications',consents:'consents',auditLogs:'audit_logs',familyMembers:'family_members',emergencyProfiles:'emergency_profiles',emergencyTokens:'emergency_tokens',donationHistory:'donation_history'}
function getStored():AppData { try {const raw=localStorage.getItem(STORE);if(raw) return {...seedData(),...JSON.parse(raw)} as AppData} catch (error) {console.error('Invalid demo state; resetting',error)} const initial=seedData();localStorage.setItem(STORE,JSON.stringify(initial));return initial }
export function resetDemoData(){localStorage.setItem(STORE,JSON.stringify(seedData()));window.dispatchEvent(new Event(evt))}
function demoActor(){try{return (JSON.parse(localStorage.getItem('carebridge-demo-session')||'{}') as {userId?:string}).userId||'demo-guest'}catch{return 'demo-guest'}}
function demoRelated(data:AppData,key:EntityKey,record:Record<string,unknown>,old?:Record<string,unknown>){
 const at=new Date().toISOString()
 const log=(action:string)=>data.auditLogs.push({id:newId(),actorId:demoActor(),action,target:String(record.id||''),detail:'Fictional local demo change',createdAt:at})
 const tell=(userId:string,title:string,message:string,type:string)=>{if(data.users.some(u=>u.id===userId))data.notifications.push({id:newId(),createdAt:at,userId,title,message,read:false,type})}
 const patient=String(record.patientId||'')
 const doctor=String(record.doctorId||'')
 if(!old){
  if(key==='appointments')tell(doctor,'New appointment','A patient requested an appointment','appointment')
  if(key==='prescriptions')tell(patient,'New prescription',String(record.medicine||'A prescription was added'),'prescription')
  if(key==='labReports')tell(patient,'Investigation requested',String(record.testName||'A test was requested'),'lab')
  if(key==='followUps')tell(patient,'Follow-up scheduled',String(record.reason||'Follow-up recorded'),'followup')
  if(key==='bloodRequests')data.users.filter(u=>u.role==='donor'&&u.availability&&u.bloodGroup===record.bloodGroup&&u.city?.toLowerCase()===String(record.city).toLowerCase()).forEach(d=>tell(d.id,'Matching fictional blood request',`Blood request at ${String(record.hospital||'hospital')}`,'blood'))
  if(key==='orders'){
   const items=record.items as Array<{name:string;quantity:number}> ||[]
   for(const item of items)data.medicineHistory.push({id:newId(),createdAt:at,patientId:patient,orderId:String(record.id),medicine:item.name,quantity:item.quantity,status:'processing'})
   tell(patient,'Pharmacy order placed','Your demonstration order is processing','order')
  }
 }else{
  if(key==='labReports'&&old.status!==record.status&&record.status==='completed')tell(patient,'Investigation result available',String(record.testName),'lab')
  if(key==='orders'&&old.status!==record.status){data.medicineHistory.filter(h=>h.orderId===record.id).forEach(h=>h.status=String(record.status));tell(patient,'Pharmacy order updated',`Order status: ${String(record.status)}`,'order')}
  if(key==='bloodRequests'&&old.status!==record.status)tell(patient,'Blood request updated',`Request status: ${String(record.status)}`,'blood')
 }
 if(key!=='auditLogs'&&key!=='notifications')log(`${old?'UPDATE':'INSERT'} ${key}`)
}
export class DemoRepository implements Repository {
  readonly mode='demo' as const
  async load(){return getStored()}
  async create<K extends EntityKey>(key:K,value:ItemOf<K>){const data=getStored();(data[key] as unknown[]).push(value);demoRelated(data,key,value as unknown as Record<string,unknown>);localStorage.setItem(STORE,JSON.stringify(data));window.dispatchEvent(new Event(evt))}
  async update<K extends EntityKey>(key:K,id:string,changes:Partial<ItemOf<K>>){const data=getStored();const ix=(data[key] as Array<{id:string}>).findIndex(x=>x.id===id);if(ix===-1)throw Error('Record not found');const old=(data[key] as unknown[])[ix] as Record<string,unknown>;const merged={...old,...changes};(data[key] as unknown[])[ix]=merged;demoRelated(data,key,merged,old);localStorage.setItem(STORE,JSON.stringify(data));window.dispatchEvent(new Event(evt))}
  async remove(key:EntityKey,id:string){const data=getStored();const records=data[key] as Array<{id:string}>;const index=records.findIndex(x=>x.id===id);if(index<0)throw Error('Record not found');records.splice(index,1);localStorage.setItem(STORE,JSON.stringify(data));window.dispatchEvent(new Event(evt))}
  subscribe(handler:()=>void){window.addEventListener(evt,handler);window.addEventListener('storage',handler);return ()=>{window.removeEventListener(evt,handler);window.removeEventListener('storage',handler)}}
  async uploadMedicalFile(_patientId:string,file:File){if(file.size>1_000_000)throw Error('Demo files must be smaller than 1 MB');if(!['application/pdf','image/png','image/jpeg'].includes(file.type))throw Error('Only PDF, PNG and JPG are supported');return new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(Error('Could not read file'));reader.readAsDataURL(file)})}
  async getMedicalFileUrl(path:string){return path}
}
const fieldMap:Record<string,string>={patientId:'patient_id',doctorId:'doctor_id',donorId:'donor_id',userId:'user_id',granteeId:'grantee_id',actorId:'actor_id'}
function encode(key:EntityKey,item:Record<string,unknown>){
  if(key==='users'){const user=item as unknown as User;return {id:user.id,full_name:user.name,email:user.email,role:user.role,blood_group:user.bloodGroup||null,city:user.city||null,phone:user.phone||null,specialty:user.specialty||null,availability:user.availability??true}}
  if(key==='pharmacyProducts'){return {id:item.id,name:item.name,category:item.category,price:item.price,stock:item.stock,description:item.description}}
  const fields:Record<string,unknown>={id:item.id,data:item}
  Object.entries(fieldMap).forEach(([js,sql])=>{if(item[js]) fields[sql]=item[js]})
  if(item.createdAt)fields.created_at=item.createdAt
  return fields
}
function decode(key:EntityKey,row:Record<string,unknown>):Record<string,unknown>{
  if(key==='users')return {id:row.id,name:row.full_name,email:row.email,role:row.role,bloodGroup:row.blood_group||'',city:row.city||'',phone:row.phone||'',specialty:row.specialty||'',availability:row.availability,joinedAt:row.created_at}
  if(key==='pharmacyProducts')return {id:row.id,name:row.name,category:row.category,price:row.price,stock:row.stock,description:row.description,createdAt:row.created_at}
  return {...(row.data as object || {}),id:row.id,createdAt:row.created_at,...Object.fromEntries(Object.entries(fieldMap).filter(([,sql])=>row[sql]).map(([js,sql])=>[js,row[sql]]))}
}
export class CloudRepository implements Repository {
  readonly mode='cloud' as const
  private cache:AppData=seedData()
  constructor(private client:SupabaseClient){ }
  async load():Promise<AppData>{
    const results=await Promise.all(ALL_KEYS.map(async key=>{
      const {data,error}=await this.client.from(TABLES[key]).select('*').limit(1000)
      if(error)throw Error(`${TABLES[key]}: ${error.message}`)
      return [key,(data||[]).map(x=>decode(key,x))] as const
    }))
    const data=Object.fromEntries(results) as unknown as AppData
    this.cache=data
    return data
  }
  async create<K extends EntityKey>(key:K,value:ItemOf<K>){const {error}=await this.client.from(TABLES[key]).insert(encode(key,value as unknown as Record<string,unknown>));if(error)throw Error(error.message)}
  async update<K extends EntityKey>(key:K,id:string,changes:Partial<ItemOf<K>>){
    if(key==='bloodRequests' && (changes as {status?:string}).status==='accepted'){const {data:{user}}=await this.client.auth.getUser();if(user){const {data:profile}=await this.client.from('users').select('role').eq('id',user.id).single();if(profile?.role==='donor'){const {error}=await this.client.rpc('cb_accept_blood_request',{request_id:id});if(error)throw Error(error.message);return}}}
    const previous=(this.cache[key] as Array<{id:string}>).find(x=>x.id===id)
    if(!previous)throw Error('Record not found or not authorized')
    const merged={...previous,...changes}
    const values=encode(key,merged as Record<string,unknown>);delete (values as Record<string,unknown>).id
    const {data,error}=await this.client.from(TABLES[key]).update(values).eq('id',id).select('id')
    if(error)throw Error(error.message)
    if(!data?.length)throw Error('Update was not authorized or record was missing')
  }
  async remove(key:EntityKey,id:string){const {data,error}=await this.client.from(TABLES[key]).delete().eq('id',id).select('id');if(error)throw Error(error.message);if(!data?.length)throw Error('Deletion was not authorized')}
  subscribe(handler:()=>void){
    const channel=this.client.channel('carebridge-active-workspace')
    for(const key of ALL_KEYS.filter(x=>x!=='emergencyTokens')) channel.on('postgres_changes',{event:'*',schema:'public',table:TABLES[key]},()=>handler())
    channel.subscribe(status=>{if(status==='CHANNEL_ERROR')console.warn('Supabase Realtime channel unavailable; reload to update')})
    return ()=>{void this.client.removeChannel(channel)}
  }
  async uploadMedicalFile(patientId:string,file:File){if(file.size>10_000_000)throw Error('Maximum file size is 10 MB');const path=`${patientId}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g,'_')}`;const {error}=await this.client.storage.from('medical-records').upload(path,file,{upsert:false});if(error)throw Error(error.message);return path}
  async getMedicalFileUrl(path:string){const {data,error}=await this.client.storage.from('medical-records').createSignedUrl(path,60);if(error)throw Error(error.message);return data.signedUrl}
}
export const repository:Repository = supabase ? new CloudRepository(supabase) : new DemoRepository()
export const newId=()=>crypto.randomUUID()
export const now=()=>new Date().toISOString()
