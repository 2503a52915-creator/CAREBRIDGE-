import type {AppData} from '../types'
export const IDS = {
  patient:'11111111-1111-4111-8111-111111111111', doctor:'22222222-2222-4222-8222-222222222222',
  admin:'33333333-3333-4333-8333-333333333333', donor:'44444444-4444-4444-8444-444444444444',
  doctor2:'55555555-5555-4555-8555-555555555555'
} as const
const when = (days=0) => {const d=new Date();d.setDate(d.getDate()+days);return d.toISOString()}
const date = (days=0) => when(days).slice(0,10)
const R=(n:number)=>`a0000000-0000-4000-8000-${String(n).padStart(12,'0')}`
export function seedData():AppData { return {
  users:[
    {id:IDS.patient,name:'Maya Shah',email:'maya@example.test',role:'patient',bloodGroup:'O+',city:'Warangal',phone:'0000000000',age:29,joinedAt:when(-160)},
    {id:IDS.doctor,name:'Dr. Arjun Mehta',email:'arjun@example.test',role:'doctor',specialty:'General Medicine',city:'Warangal',joinedAt:when(-190)},
    {id:IDS.doctor2,name:'Dr. Kavya Rao',email:'kavya@example.test',role:'doctor',specialty:'Cardiology',city:'Hyderabad',joinedAt:when(-190)},
    {id:IDS.admin,name:'CareBridge Admin',email:'admin@example.test',role:'admin',joinedAt:when(-190)},
    {id:IDS.donor,name:'Riya Kumar',email:'riya@example.test',role:'donor',bloodGroup:'O+',city:'Warangal',phone:'0000000000',availability:true,joinedAt:when(-80)}
  ],
  appointments:[{id:R(1),createdAt:when(-3),patientId:IDS.patient,doctorId:IDS.doctor,date:date(2),time:'10:30',reason:'Routine follow-up consultation',mode:'in-person',status:'scheduled'},{id:R(2),createdAt:when(-24),patientId:IDS.patient,doctorId:IDS.doctor,date:date(-20),time:'11:00',reason:'General wellness check',mode:'video',status:'completed'}],
  consultations:[{id:R(3),createdAt:when(-20),patientId:IDS.patient,doctorId:IDS.doctor,appointmentId:R(2),notes:'Patient reports overall well-being. Reviewed existing medications and preventive care.',status:'completed'}],
  prescriptions:[{id:R(4),createdAt:when(-20),patientId:IDS.patient,doctorId:IDS.doctor,medicine:'Sample Vitamin D',dosage:'As recorded by clinician',frequency:'Once weekly',duration:'4 weeks',instructions:'Fictional demonstration prescription. Do not use for treatment.'}],
  labReports:[{id:R(5),createdAt:when(-3),patientId:IDS.patient,doctorId:IDS.doctor,testName:'Complete blood count (demo)',status:'pending',result:'',notes:'Fictional investigation request'},{id:R(6),createdAt:when(-21),patientId:IDS.patient,doctorId:IDS.doctor,testName:'Lipid profile (demo)',status:'completed',result:'Demo result: clinician review complete',notes:'Fictional result'}],
  carePlans:[{id:R(7),createdAt:when(-20),patientId:IDS.patient,doctorId:IDS.doctor,title:'Wellness check-in',details:'Review routine health records and attend upcoming follow-up.',dueDate:date(10),status:'active'}],
  followUps:[{id:R(8),createdAt:when(-20),patientId:IDS.patient,doctorId:IDS.doctor,date:date(14),reason:'Review wellness plan and lab result',status:'scheduled'}],
  medicalRecords:[{id:R(9),createdAt:when(-36),patientId:IDS.patient,title:'Fictional medical intake',category:'Consultation',notes:'Sample record entered solely for CAREBRIDGE demonstration.'}],
  bloodRequests:[{id:R(10),createdAt:when(-2),patientId:IDS.patient,bloodGroup:'O+',city:'Warangal',hospital:'Sample District Hospital',units:2,urgency:'High',status:'open',notes:'Fictional training request; no real blood needed.'}],
  organDonors:[],organRequests:[],
  pharmacyProducts:[
    {id:R(20),createdAt:when(-40),name:'Sample Vitamin D',category:'Supplements',price:120,stock:50,description:'Demonstration catalog item; not medical advice'},
    {id:R(21),createdAt:when(-40),name:'Sample Hydration Salts',category:'Wellness',price:38,stock:80,description:'Demonstration catalog item'},
    {id:R(22),createdAt:when(-40),name:'Basic First Aid Kit',category:'First Aid',price:240,stock:35,description:'Demonstration catalog item'},
    {id:R(23),createdAt:when(-40),name:'Digital Thermometer',category:'Devices',price:320,stock:25,description:'Demonstration catalog item'}
  ],
  orders:[{id:R(24),createdAt:when(-8),patientId:IDS.patient,items:[{productId:R(23),name:'Digital Thermometer',quantity:1,price:320}],amount:320,status:'delivered'}],
  medicineHistory:[{id:R(25),createdAt:when(-8),patientId:IDS.patient,orderId:R(24),medicine:'Digital Thermometer',quantity:1,status:'delivered'}],
  notifications:[{id:R(26),createdAt:when(-3),userId:IDS.patient,title:'Appointment confirmed',message:'Your upcoming appointment has been added to your care journey.',read:false,type:'appointment'},{id:R(27),createdAt:when(-3),userId:IDS.doctor,title:'Investigation pending',message:'A patient investigation is awaiting a result.',read:false,type:'lab'}],
  consents:[{id:R(28),createdAt:when(-30),patientId:IDS.patient,granteeId:IDS.doctor,scope:'treatment',active:true}],
  auditLogs:[{id:R(29),createdAt:when(-30),actorId:IDS.patient,action:'Consent granted',target:IDS.doctor,detail:'Treatment access to fictional demo record'}],
  familyMembers:[{id:R(30),createdAt:when(-40),patientId:IDS.patient,name:'Aarav Shah',relationship:'Sibling',bloodGroup:'A+',phone:'0000000000',authorized:false}],
  emergencyProfiles:[{id:R(31),createdAt:when(-30),patientId:IDS.patient,bloodGroup:'O+',allergies:'None documented in demo',emergencyContact:'Aarav Shah',emergencyPhone:'0000000000',notes:'Fictional profile — no real emergency use'}],
  emergencyTokens:[],donationHistory:[]
}}
