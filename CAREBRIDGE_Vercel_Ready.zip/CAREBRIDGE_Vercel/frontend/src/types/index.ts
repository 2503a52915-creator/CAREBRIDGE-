export type Role = 'patient' | 'doctor' | 'admin' | 'donor'
export type EntityKey = 'appointments'|'consultations'|'prescriptions'|'labReports'|'carePlans'|'followUps'|'medicalRecords'|'bloodRequests'|'organDonors'|'organRequests'|'orders'|'medicineHistory'|'notifications'|'consents'|'auditLogs'|'familyMembers'|'emergencyProfiles'|'emergencyTokens'|'pharmacyProducts'|'users'|'donationHistory'
export interface User {id: string; name: string; email: string; role: Role; bloodGroup?: string; city?: string; phone?: string; specialty?: string; age?: number; availability?: boolean; joinedAt?: string}
export interface BaseRecord {id: string; createdAt: string; [key: string]: unknown}
export interface Appointment extends BaseRecord {patientId: string; doctorId: string; date: string; time: string; reason: string; mode: 'in-person'|'video'|'audio'|'chat'; status: string}
export interface Consultation extends BaseRecord {patientId: string; doctorId: string; appointmentId?: string; notes: string; status: string}
export interface Prescription extends BaseRecord {patientId: string; doctorId: string; medicine: string; dosage: string; frequency: string; duration: string; instructions: string}
export interface LabReport extends BaseRecord {patientId: string; doctorId: string; testName: string; status: string; result: string; notes?: string}
export interface CarePlan extends BaseRecord {patientId: string; doctorId: string; title: string; details: string; dueDate: string; status: string}
export interface FollowUp extends BaseRecord {patientId: string; doctorId: string; date: string; reason: string; status: string}
export interface MedicalRecord extends BaseRecord {patientId: string; title: string; category: string; notes: string; filePath?: string}
export interface BloodRequest extends BaseRecord {patientId: string; bloodGroup: string; city: string; hospital: string; units: number; urgency: string; status: string; acceptedBy?: string; notes?: string}
export interface OrganDonor extends BaseRecord {donorId: string; organ: string; status: string}
export interface OrganRequest extends BaseRecord {patientId: string; organ: string; hospital: string; status: string}
export interface PharmacyProduct extends BaseRecord {name: string; category: string; price: number; stock: number; description: string}
export interface Order extends BaseRecord {patientId: string; items: Array<{productId: string; name: string; quantity: number; price: number}>; amount: number; status: string}
export interface MedicineHistory extends BaseRecord {patientId: string; orderId: string; medicine: string; quantity: number; status: string}
export interface Notice extends BaseRecord {userId: string; title: string; message: string; read: boolean; type: string}
export interface Consent extends BaseRecord {patientId: string; granteeId: string; scope: string; active: boolean}
export interface AuditLog extends BaseRecord {actorId: string; action: string; target: string; detail: string}
export interface FamilyMember extends BaseRecord {patientId: string; name: string; relationship: string; bloodGroup: string; phone: string; authorized: boolean}
export interface EmergencyProfile extends BaseRecord {patientId: string; bloodGroup: string; allergies: string; emergencyContact: string; emergencyPhone: string; notes: string}
export interface EmergencyToken extends BaseRecord {patientId: string; token: string; pinHash: string; expiresAt: string; revoked: boolean; attempts: number}
export interface DonationHistory extends BaseRecord {donorId: string; requestId: string; status: string}
export interface AppData {
  users: User[]; appointments: Appointment[]; consultations: Consultation[]; prescriptions: Prescription[]; labReports: LabReport[]; carePlans: CarePlan[]; followUps: FollowUp[]; medicalRecords: MedicalRecord[];
  bloodRequests: BloodRequest[]; organDonors: OrganDonor[]; organRequests: OrganRequest[]; pharmacyProducts: PharmacyProduct[]; orders: Order[]; medicineHistory: MedicineHistory[]; notifications: Notice[]; consents: Consent[]; auditLogs: AuditLog[]; familyMembers: FamilyMember[]; emergencyProfiles: EmergencyProfile[]; emergencyTokens: EmergencyToken[]; donationHistory: DonationHistory[]
}
export interface Session {userId: string; mode: 'demo'|'cloud'}
export type ItemOf<K extends EntityKey> = AppData[K][number]
export interface Repository {
  mode: 'demo'|'cloud';
  load(): Promise<AppData>;
  create<K extends EntityKey>(key: K, value: ItemOf<K>): Promise<void>;
  update<K extends EntityKey>(key: K, id: string, changes: Partial<ItemOf<K>>): Promise<void>;
  remove(key: EntityKey, id: string): Promise<void>;
  subscribe(handler: () => void): () => void;
  uploadMedicalFile?(patientId: string, file: File): Promise<string>;
  getMedicalFileUrl?(path: string): Promise<string>;
}
