import type {AppData, User} from '../types'
export const shortDate=(value:string)=>{if(!value)return '—';const d=new Date(value.includes('T')?value:value+'T12:00:00');return Number.isNaN(d.getTime())?value:d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})}
export const money=(value:number)=>`₹${value.toLocaleString('en-IN')}`
export const getDoctor=(data:AppData,id:string)=>data.users.find(u=>u.id===id)?.name||'Doctor'
export const getPatient=(data:AppData,id:string)=>data.users.find(u=>u.id===id)?.name||'Patient'
export const isAuthorized=(data:AppData,doctorId:string,patientId:string)=>data.consents.some(c=>c.patientId===patientId&&c.granteeId===doctorId&&c.active)
export function careGaps(data:AppData,patientId:string){
  return [
    ...data.labReports.filter(x=>x.patientId===patientId&&x.status==='pending').map(x=>({id:x.id,title:`Result pending: ${x.testName}`,detail:'Investigation has been requested but no result is recorded.',priority:'High',type:'lab'})),
    ...data.followUps.filter(x=>x.patientId===patientId&&x.status==='scheduled'&&new Date(x.date)<new Date(new Date().toDateString())).map(x=>({id:x.id,title:'Follow-up needs attention',detail:`Follow-up planned for ${shortDate(x.date)} has passed.`,priority:'Medium',type:'followup'})),
    ...data.carePlans.filter(x=>x.patientId===patientId&&x.status==='active'&&new Date(x.dueDate)<new Date(new Date().toDateString())).map(x=>({id:x.id,title:`Care plan overdue: ${x.title}`,detail:'Plan due date has passed.',priority:'Medium',type:'plan'}))
  ]
}
export function summary(data:AppData,patient:User){
  const id=patient.id
  const a=data.appointments.filter(x=>x.patientId===id)
  const labs=data.labReports.filter(x=>x.patientId===id)
  const rx=data.prescriptions.filter(x=>x.patientId===id)
  const gaps=careGaps(data,id)
  const followups=data.followUps.filter(x=>x.patientId===id&&x.status==='scheduled')
  return [`${patient.name}'s fictional care record contains ${a.length} appointment(s), ${rx.length} prescription(s), and ${labs.length} investigation(s).`,
  `${labs.filter(x=>x.status==='completed').length} investigation result(s) are recorded and ${labs.filter(x=>x.status==='pending').length} are still pending.`,
  `${gaps.length} administrative care gap(s) are visible for follow-up. ${followups.length} follow-up(s) are scheduled.`,
  'This is an organization of existing records, not a diagnosis, medical interpretation, or treatment recommendation.']
}
export function timeline(data:AppData,patientId:string){
  const items=[...data.appointments.filter(x=>x.patientId===patientId).map(x=>({id:x.id,date:x.createdAt,title:'Appointment booked',detail:`${x.reason} · ${shortDate(x.date)}`,kind:'appointment'})),
  ...data.prescriptions.filter(x=>x.patientId===patientId).map(x=>({id:x.id,date:x.createdAt,title:'Prescription added',detail:x.medicine,kind:'prescription'})),
  ...data.labReports.filter(x=>x.patientId===patientId).map(x=>({id:x.id,date:x.createdAt,title:'Investigation '+x.status,detail:x.testName,kind:'lab'})),
  ...data.followUps.filter(x=>x.patientId===patientId).map(x=>({id:x.id,date:x.createdAt,title:'Follow-up scheduled',detail:shortDate(x.date),kind:'followup'})),
  ...data.orders.filter(x=>x.patientId===patientId).map(x=>({id:x.id,date:x.createdAt,title:'Medicine order '+x.status,detail:money(x.amount),kind:'order'})),
  ...data.medicalRecords.filter(x=>x.patientId===patientId).map(x=>({id:x.id,date:x.createdAt,title:'Medical record added',detail:x.title,kind:'record'}))]
  return items.sort((a,b)=>b.date.localeCompare(a.date))
}
