import {describe,it,expect} from 'vitest'
import {seedData,IDS} from '../services/seed'
import {careGaps,isAuthorized,summary,timeline} from './health'
describe('connected fictional care records',()=>{
 it('offers demo users in every role',()=>{const data=seedData();expect(new Set(data.users.map(x=>x.role))).toEqual(new Set(['patient','doctor','admin','donor']))})
 it('limits a doctor to consent-authorized patient records',()=>{const data=seedData();expect(isAuthorized(data,IDS.doctor,IDS.patient)).toBe(true);expect(isAuthorized(data,IDS.doctor2,IDS.patient)).toBe(false);data.consents[0].active=false;expect(isAuthorized(data,IDS.doctor,IDS.patient)).toBe(false)})
 it('reports a gap for a pending investigation and clears it on result',()=>{const data=seedData();const initial=careGaps(data,IDS.patient);expect(initial.some(x=>x.title.includes('Complete blood count'))).toBe(true);data.labReports.find(x=>x.status==='pending')!.status='completed';expect(careGaps(data,IDS.patient).length).toBe(initial.length-1)})
 it('builds an ordered health journey across modules',()=>{const data=seedData();const journey=timeline(data,IDS.patient);expect(journey.some(x=>x.kind==='prescription')).toBe(true);expect(journey.some(x=>x.kind==='lab')).toBe(true);expect(journey.every((x,i)=>i===0||journey[i-1].date>=x.date)).toBe(true)})
 it('uses existing records, not AI medical predictions',()=>{const data=seedData();const patient=data.users.find(x=>x.id===IDS.patient)!;expect(summary(data,patient).join(' ')).toContain('not a diagnosis')})
})
