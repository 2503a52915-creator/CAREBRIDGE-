import {createContext,useCallback,useContext,useEffect,useMemo,useState,type ReactNode} from 'react'
import type {AppData,EntityKey,ItemOf,Role,Session,User} from '../types'
import {repository,supabase,newId,now,resetDemoData} from '../services/repository'
import {seedData} from '../services/seed'
import {isAuthorized} from '../utils/health'

type ContextValue={
 data:AppData; user:User|null; session:Session|null; loading:boolean; busy:boolean; mode:'demo'|'cloud';
 toast:(message:string,error?:boolean)=>void; notice:{message:string;error:boolean}|null;
 demoLogin:(role:Role)=>void; login:(email:string,password:string)=>Promise<void>; register:(name:string,email:string,password:string,role:'patient'|'donor')=>Promise<string>; forgot:(email:string)=>Promise<void>; logout:()=>Promise<void>;
 act:<K extends EntityKey>(key:K,value:ItemOf<K>)=>Promise<void>; edit:<K extends EntityKey>(key:K,id:string,changes:Partial<ItemOf<K>>)=>Promise<void>; del:(key:EntityKey,id:string)=>Promise<void>;
 canAccess:(patientId:string)=>boolean; reset:()=>void; refresh:()=>Promise<AppData>;
}
const AppCtx=createContext<ContextValue|null>(null)
const SESSION_KEY='carebridge-demo-session'
const defaultData=seedData()
export function AppProvider({children}:{children:ReactNode}){
 const [data,setData]=useState<AppData>(defaultData)
 const [session,setSession]=useState<Session|null>(null)
 const [user,setUser]=useState<User|null>(null)
 const [loading,setLoading]=useState(true)
 const [busy,setBusy]=useState(false)
 const [notice,setNotice]=useState<{message:string;error:boolean}|null>(null)
 const toast=useCallback((message:string,error=false)=>setNotice({message,error}),[])
 const refresh=useCallback(async()=>{const incoming=await repository.load();setData(incoming);return incoming},[])
 useEffect(()=>{
  let active=true
  const init=async()=>{
   try{
    const state=await repository.load();if(!active)return;setData(state)
    if(repository.mode==='demo'){
      const stored=localStorage.getItem(SESSION_KEY);if(stored){const current=JSON.parse(stored) as Session;const found=state.users.find(u=>u.id===current.userId);if(found){setSession(current);setUser(found)}}
    } else if(supabase){
      const {data:{user:authUser},error}=await supabase.auth.getUser();if(error && error.name!=='AuthSessionMissingError')throw error
      if(authUser){const current=state.users.find(u=>u.id===authUser.id);if(current){setSession({userId:authUser.id,mode:'cloud'});setUser(current)}}
    }
   }catch(error){console.error(error);toast(error instanceof Error?error.message:'Unable to initialize app',true)}finally{if(active)setLoading(false)}
  }
  void init()
  const unsub=repository.subscribe(()=>{void repository.load().then(incoming=>{if(active){setData(incoming);setUser(existing=>existing?incoming.users.find(u=>u.id===existing.id)||null:null)}}).catch(error=>{if(active)toast(error instanceof Error?error.message:'Realtime refresh failed',true)})})
  const {data:authSubscription}=supabase?.auth.onAuthStateChange((_event,authSession)=>{
   // Supabase recommends deferring additional database work outside the auth callback.
   queueMicrotask(()=>{if(!active)return;if(!authSession){setSession(null);setUser(null)}else{void repository.load().then(state=>{if(active){setData(state);setSession({userId:authSession.user.id,mode:'cloud'});setUser(state.users.find(u=>u.id===authSession.user.id)||null)}}).catch(error=>toast(error instanceof Error?error.message:'Auth refresh failed',true))}})
  })||{data:{subscription:null}}
  return ()=>{active=false;unsub();authSubscription.subscription?.unsubscribe()}
 },[toast])
 const demoLogin=(role:Role)=>{if(repository.mode!=='demo')throw Error('Demo role switch is available only in demo mode');const found=data.users.find(x=>x.role===role);if(!found)throw Error('Demo role not found');const s:Session={userId:found.id,mode:'demo'};localStorage.setItem(SESSION_KEY,JSON.stringify(s));setSession(s);setUser(found);toast(`Signed in as ${found.name} · fictional demo`)}
 const login=async(email:string,password:string)=>{if(!supabase)throw Error('Cloud sign-in needs Supabase credentials');setBusy(true);try{const {error}=await supabase.auth.signInWithPassword({email,password});if(error)throw Error(error.message);await refresh();toast('Signed in successfully')}finally{setBusy(false)}}
 const register=async(name:string,email:string,password:string,role:'patient'|'donor')=>{if(!supabase)throw Error('Cloud registration needs Supabase credentials');setBusy(true);try{const {data:response,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name,role}}});if(error)throw Error(error.message);return response.session?'Registration complete.':'Account created. Check your email for the confirmation link.'}finally{setBusy(false)}}
 const forgot=async(email:string)=>{if(!supabase)throw Error('Cloud reset needs Supabase credentials');const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:window.location.origin+'/auth'});if(error)throw Error(error.message);toast('If this address has an account, a reset email has been sent.')}
 const logout=async()=>{if(supabase){const {error}=await supabase.auth.signOut();if(error)throw Error(error.message)}else localStorage.removeItem(SESSION_KEY);setSession(null);setUser(null)}
 const guard=(key:EntityKey,record:Record<string,unknown>,isEdit=false)=>{
  if(!user)throw Error('Sign in required')
  if(repository.mode!=='demo')return // Postgres RLS is the authoritative authorization in cloud mode.
  if(user.role==='admin')return
  if(key==='auditLogs'||key==='notifications')return
  if(key==='users'){if(record.id!==user.id || record.role && record.role!==user.role)throw Error('Not authorized to manage this account');return}
  if(key==='pharmacyProducts')throw Error('Only admins can change the product catalog')
  const patientId=String(record.patientId||'')
  const doctorId=String(record.doctorId||'')
  const donorId=String(record.donorId||'')
  const granteeId=String(record.granteeId||'')
  if(user.role==='patient' && (patientId===user.id || (key==='consents'&&granteeId===user.id)))return
  if(user.role==='doctor' && (key==='appointments'&&doctorId===user.id || (patientId && isAuthorized(data,user.id,patientId) && (doctorId===user.id || key==='medicalRecords'))))return
  if(user.role==='donor' && donorId===user.id)return
  if(user.role==='donor'&&key==='bloodRequests'&&isEdit){const old=data.bloodRequests.find(r=>r.id===record.id);if(old&&old.status==='open'&&old.bloodGroup===user.bloodGroup&&old.city.toLowerCase()===user.city?.toLowerCase()&&user.availability&&record.acceptedBy===user.id&&record.status==='accepted')return;if(old&&old.acceptedBy===user.id&&old.status==='accepted'&&record.status==='completed')return;throw Error('Donation request is not available to your role')}
  throw Error('Not authorized for this action')
 }
 const transact=async(action:()=>Promise<void>,message:string)=>{setBusy(true);try{await action();await refresh();toast(message)}catch(error){const msg=error instanceof Error?error.message:'Operation failed';toast(msg,true);throw error}finally{setBusy(false)}}
 const act=async<K extends EntityKey>(key:K,value:ItemOf<K>)=>{guard(key,value as unknown as Record<string,unknown>);await transact(()=>repository.create(key,value),`${key.replace(/([A-Z])/g,' $1')} saved`)}
 const edit=async<K extends EntityKey>(key:K,id:string,changes:Partial<ItemOf<K>>)=>{const prior=(data[key] as Array<{id:string}>).find(x=>x.id===id);if(!prior)throw Error('Record not found');guard(key,{...prior,...changes},true);await transact(()=>repository.update(key,id,changes),'Changes saved')}
 const del=async(key:EntityKey,id:string)=>{const prior=(data[key] as Array<{id:string}>).find(x=>x.id===id);if(!prior)throw Error('Record not found');guard(key,prior as unknown as Record<string,unknown>,true);await transact(()=>repository.remove(key,id),'Record removed')}
 const canAccess=(patientId:string)=>!!user&&(user.role==='admin'||user.role==='patient'&&user.id===patientId||user.role==='doctor'&&isAuthorized(data,user.id,patientId))
 const reset=()=>{if(repository.mode!=='demo')return;resetDemoData();toast('Fictional demo data reset successfully')}
 const value=useMemo(()=>({data,user,session,loading,busy,mode:repository.mode,notice,toast,demoLogin,login,register,forgot,logout,act,edit,del,canAccess,reset,refresh}),[data,user,session,loading,busy,notice,toast])
 return <AppCtx.Provider value={value}><>{children}{notice&&<div className={`toast-notice ${notice.error?'error':''}`} role="status"><span>{notice.message}</span><button type="button" onClick={()=>setNotice(null)} aria-label="Dismiss message">×</button></div>}</></AppCtx.Provider>
}
export const useApp=()=>{const value=useContext(AppCtx);if(!value)throw Error('AppProvider missing');return value}
export const record=<T extends object>(value:T):T&{id:string;createdAt:string}=>({...value,id:newId(),createdAt:now()})
