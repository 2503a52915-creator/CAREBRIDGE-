-- CAREBRIDGE educational prototype · Supabase PostgreSQL schema and row level security
-- Run once in Supabase SQL Editor on a NEW project.
-- No real health records should be stored without appropriate production controls and professional review.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN CREATE TYPE public.carebridge_role AS ENUM ('patient','doctor','admin','donor'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE TABLE IF NOT EXISTS public.users (
 id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 full_name text NOT NULL DEFAULT 'New user', email text NOT NULL DEFAULT '',
 role public.carebridge_role NOT NULL DEFAULT 'patient',
 blood_group text, city text, phone text, specialty text, availability boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT user_name_length CHECK (char_length(full_name) BETWEEN 2 AND 120)
);
CREATE INDEX IF NOT EXISTS users_role_idx ON public.users(role);

-- All workflow tables have a searchable relational ownership layer and flexible application-specific JSON payload.
-- JSON data is deliberately used to keep the app's local and Supabase repository interfaces identical.
-- A future production release should replace it with strictly normalized typed clinical entities.
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY[
 'patients','doctors','donors','family_members','appointments','consultations',
 'prescriptions','medical_records','lab_reports','care_plans','care_gaps','follow_ups',
 'emergency_profiles','emergency_access_logs','blood_requests','blood_donors',
 'organ_donors','organ_requests','medicine_orders','medicine_history','notifications',
 'consents','audit_logs','emergency_tokens','donation_history'] LOOP
 EXECUTE format('CREATE TABLE IF NOT EXISTS public.%I (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  doctor_id uuid REFERENCES public.users(id) ON DELETE SET NULL,
  donor_id uuid REFERENCES public.users(id) ON DELETE SET NULL,
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  grantee_id uuid REFERENCES public.users(id) ON DELETE SET NULL,
  actor_id uuid REFERENCES public.users(id) ON DELETE SET NULL,
  data jsonb NOT NULL DEFAULT ''{}''::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT %I CHECK (jsonb_typeof(data) = ''object'')
 )',t,t||'_payload_object');
 EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I(patient_id, created_at DESC)',t||'_patient_idx',t);
 EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I(doctor_id, created_at DESC)',t||'_doctor_idx',t);
 EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I(donor_id, created_at DESC)',t||'_donor_idx',t);
 EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I(user_id, created_at DESC)',t||'_user_idx',t);
 END LOOP;
END $$;
CREATE TABLE IF NOT EXISTS public.pharmacy_products (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL, category text NOT NULL DEFAULT 'Other',
 price numeric(12,2) NOT NULL DEFAULT 0 CHECK(price >= 0),
 stock int NOT NULL DEFAULT 0 CHECK(stock >= 0), description text,
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS pharmacy_products_name_idx ON public.pharmacy_products(name);
CREATE INDEX IF NOT EXISTS blood_requests_match_idx ON public.blood_requests((data->>'bloodGroup'),(lower(data->>'city')));
CREATE UNIQUE INDEX IF NOT EXISTS emergency_tokens_token_idx ON public.emergency_tokens((data->>'token'));

-- Current user/permissions are evaluated by SECURITY DEFINER functions to avoid recursive users RLS.
CREATE OR REPLACE FUNCTION public.cb_role() RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
 SELECT role::text FROM public.users WHERE id = (SELECT auth.uid())
$$;
CREATE OR REPLACE FUNCTION public.cb_is_admin() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
 SELECT coalesce((SELECT role='admin' FROM public.users WHERE id=(SELECT auth.uid())),false)
$$;
CREATE OR REPLACE FUNCTION public.cb_can_read_patient(p uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
 SELECT p IS NOT NULL AND (
 p=(SELECT auth.uid()) OR public.cb_is_admin() OR
 (public.cb_role()='doctor' AND EXISTS (
  SELECT 1 FROM public.consents c WHERE c.patient_id=p AND c.grantee_id=(SELECT auth.uid()) AND c.data->>'active'='true'
  AND c.data->>'scope'='treatment'
 )))
$$;
CREATE OR REPLACE FUNCTION public.cb_is_authorized_doctor(p uuid,d uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
 SELECT public.cb_role()='doctor' AND d=(SELECT auth.uid()) AND EXISTS (
 SELECT 1 FROM public.consents c WHERE c.patient_id=p AND c.grantee_id=d AND c.data->>'active'='true' AND c.data->>'scope'='treatment')
$$;

-- Registration creates an account profile with patient/donor role ONLY, regardless of client metadata.
CREATE OR REPLACE FUNCTION public.cb_new_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE requested text;
BEGIN
 requested:=coalesce(new.raw_user_meta_data->>'role','patient');
 IF requested NOT IN ('patient','donor') THEN requested:='patient'; END IF;
 INSERT INTO public.users(id,email,full_name,role)
 VALUES(new.id,coalesce(new.email,''),left(coalesce(nullif(new.raw_user_meta_data->>'full_name',''),'New user'),120),requested::public.carebridge_role)
 ON CONFLICT(id) DO NOTHING;
 RETURN new;
END;$$;
DROP TRIGGER IF EXISTS cb_auth_user_created ON auth.users;
CREATE TRIGGER cb_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.cb_new_user();

-- Non-admin users cannot escalate or overwrite role/email fields via a profile update.
CREATE OR REPLACE FUNCTION public.cb_protect_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF new.id<>old.id OR (new.role IS DISTINCT FROM old.role) OR (new.email IS DISTINCT FROM old.email) THEN
  IF NOT public.cb_is_admin() THEN RAISE EXCEPTION 'Role and account identity cannot be changed'; END IF;
 END IF;
 RETURN new;
END;$$;
DROP TRIGGER IF EXISTS cb_users_protect ON public.users;
CREATE TRIGGER cb_users_protect BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.cb_protect_user();

-- Consistent created and updated timestamps.
CREATE OR REPLACE FUNCTION public.cb_timestamp() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at=now(); RETURN NEW; END;$$;
DO $$DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY[
 'patients','doctors','donors','family_members','appointments','consultations','prescriptions',
 'medical_records','lab_reports','care_plans','care_gaps','follow_ups','emergency_profiles',
 'emergency_access_logs','blood_requests','blood_donors','organ_donors','organ_requests',
 'medicine_orders','medicine_history','notifications','consents','audit_logs','emergency_tokens',
 'donation_history','pharmacy_products'] LOOP
 EXECUTE format('DROP TRIGGER IF EXISTS cb_touch ON public.%I',t);
 EXECUTE format('CREATE TRIGGER cb_touch BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.cb_timestamp()',t);
END LOOP; END $$;

-- Enable RLS for every table. SELECT/insert/update/delete are separately policy-controlled.
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
CREATE POLICY cb_users_read ON public.users FOR SELECT TO authenticated USING (
 id=(SELECT auth.uid()) OR public.cb_is_admin() OR role='doctor' OR
 (role='patient' AND public.cb_can_read_patient(id))
);
CREATE POLICY cb_users_update ON public.users FOR UPDATE TO authenticated USING(id=(SELECT auth.uid()) OR public.cb_is_admin()) WITH CHECK(id=(SELECT auth.uid()) OR public.cb_is_admin());
DO $$DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY[
 'patients','doctors','donors','family_members','appointments','consultations','prescriptions',
 'medical_records','lab_reports','care_plans','care_gaps','follow_ups','emergency_profiles',
 'emergency_access_logs','blood_requests','blood_donors','organ_donors','organ_requests',
 'medicine_orders','medicine_history','notifications','consents','audit_logs','emergency_tokens',
 'donation_history','pharmacy_products'] LOOP
 EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
END LOOP; END $$;

-- Clinical records readable by patient, consent-authorized doctor, or administrator.
-- Only consent-authorized doctors create/edit clinical notes, prescriptions and investigations.
DO $$DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY['consultations','prescriptions','lab_reports','care_plans','follow_ups'] LOOP
 EXECUTE format('CREATE POLICY cb_%I_read ON public.%I FOR SELECT TO authenticated USING(public.cb_can_read_patient(patient_id))',t,t);
 EXECUTE format('CREATE POLICY cb_%I_insert ON public.%I FOR INSERT TO authenticated WITH CHECK(public.cb_is_authorized_doctor(patient_id,doctor_id))',t,t);
 EXECUTE format('CREATE POLICY cb_%I_update ON public.%I FOR UPDATE TO authenticated USING(public.cb_is_authorized_doctor(patient_id,doctor_id)) WITH CHECK(public.cb_is_authorized_doctor(patient_id,doctor_id))',t,t);
END LOOP; END $$;

-- Appointments may be booked by patients; assigned doctors can see/update appointments even before clinical consent.
CREATE POLICY cb_appt_select ON public.appointments FOR SELECT TO authenticated USING(patient_id=auth.uid() OR doctor_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_appt_insert ON public.appointments FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid() AND doctor_id IN (SELECT id FROM public.users WHERE role='doctor'));
CREATE POLICY cb_appt_update ON public.appointments FOR UPDATE TO authenticated USING(patient_id=auth.uid() OR doctor_id=auth.uid()) WITH CHECK(patient_id=auth.uid() OR doctor_id=auth.uid());

CREATE POLICY cb_records_select ON public.medical_records FOR SELECT TO authenticated USING(public.cb_can_read_patient(patient_id));
CREATE POLICY cb_records_insert ON public.medical_records FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid() OR public.cb_is_authorized_doctor(patient_id,doctor_id));
CREATE POLICY cb_records_update ON public.medical_records FOR UPDATE TO authenticated USING(patient_id=auth.uid() OR public.cb_is_authorized_doctor(patient_id,doctor_id)) WITH CHECK(patient_id=auth.uid() OR public.cb_is_authorized_doctor(patient_id,doctor_id));

-- Patient-managed data tables.
DO $$DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY['family_members','emergency_profiles','organ_requests','patients','care_gaps'] LOOP
 EXECUTE format('CREATE POLICY cb_%I_sel ON public.%I FOR SELECT TO authenticated USING(patient_id=auth.uid() OR public.cb_is_admin())',t,t);
 EXECUTE format('CREATE POLICY cb_%I_ins ON public.%I FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid())',t,t);
 EXECUTE format('CREATE POLICY cb_%I_upd ON public.%I FOR UPDATE TO authenticated USING(patient_id=auth.uid()) WITH CHECK(patient_id=auth.uid())',t,t);
END LOOP; END $$;
CREATE POLICY cb_consent_sel ON public.consents FOR SELECT TO authenticated USING(patient_id=auth.uid() OR grantee_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_consent_ins ON public.consents FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid() AND data->>'scope'='treatment');
CREATE POLICY cb_consent_upd ON public.consents FOR UPDATE TO authenticated USING(patient_id=auth.uid()) WITH CHECK(patient_id=auth.uid());

-- Donors are not granted read access to unrelated clinical information.
CREATE POLICY cb_donor_self ON public.donors FOR ALL TO authenticated USING(donor_id=auth.uid() OR public.cb_is_admin()) WITH CHECK(donor_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_blood_donor_self ON public.blood_donors FOR ALL TO authenticated USING(donor_id=auth.uid() OR public.cb_is_admin()) WITH CHECK(donor_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_organ_donor_select ON public.organ_donors FOR SELECT TO authenticated USING(donor_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_organ_donor_insert ON public.organ_donors FOR INSERT TO authenticated WITH CHECK(donor_id=auth.uid());
CREATE POLICY cb_organ_donor_update ON public.organ_donors FOR UPDATE TO authenticated USING(donor_id=auth.uid()) WITH CHECK(donor_id=auth.uid());
CREATE POLICY cb_donation_hist_sel ON public.donation_history FOR SELECT TO authenticated USING(donor_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_donation_hist_ins ON public.donation_history FOR INSERT TO authenticated WITH CHECK(donor_id=auth.uid());
CREATE POLICY cb_donation_hist_upd ON public.donation_history FOR UPDATE TO authenticated USING(donor_id=auth.uid()) WITH CHECK(donor_id=auth.uid());

-- Donors may see requests matching their declared blood group and city; never show unrelated records.
CREATE POLICY cb_blood_req_select ON public.blood_requests FOR SELECT TO authenticated USING(
 patient_id=auth.uid() OR public.cb_is_admin() OR
 (public.cb_role()='donor' AND EXISTS (
 SELECT 1 FROM public.users u WHERE u.id=auth.uid() AND u.availability=true
 AND u.blood_group=data->>'bloodGroup' AND lower(coalesce(u.city,''))=lower(coalesce(data->>'city',''))
 AND (data->>'status'='open' OR data->>'acceptedBy'=auth.uid()::text)))
);
CREATE POLICY cb_blood_req_insert ON public.blood_requests FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid());
CREATE POLICY cb_blood_req_update ON public.blood_requests FOR UPDATE TO authenticated USING(patient_id=auth.uid() OR public.cb_is_admin()) WITH CHECK(patient_id=auth.uid() OR public.cb_is_admin());

CREATE POLICY cb_orders_sel ON public.medicine_orders FOR SELECT TO authenticated USING(patient_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_orders_ins ON public.medicine_orders FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid());
CREATE POLICY cb_orders_upd ON public.medicine_orders FOR UPDATE TO authenticated USING(public.cb_is_admin()) WITH CHECK(public.cb_is_admin());
CREATE POLICY cb_mhist_sel ON public.medicine_history FOR SELECT TO authenticated USING(patient_id=auth.uid() OR public.cb_is_admin());

CREATE POLICY cb_product_select ON public.pharmacy_products FOR SELECT TO authenticated USING(true);
CREATE POLICY cb_product_admin ON public.pharmacy_products FOR ALL TO authenticated USING(public.cb_is_admin()) WITH CHECK(public.cb_is_admin());

CREATE POLICY cb_notice_sel ON public.notifications FOR SELECT TO authenticated USING(user_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_notice_upd ON public.notifications FOR UPDATE TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
CREATE POLICY cb_audit_sel ON public.audit_logs FOR SELECT TO authenticated USING(actor_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_accesslog_sel ON public.emergency_access_logs FOR SELECT TO authenticated USING(patient_id=auth.uid() OR public.cb_is_admin());
CREATE POLICY cb_tokens_sel ON public.emergency_tokens FOR SELECT TO authenticated USING(patient_id=auth.uid());
CREATE POLICY cb_tokens_ins ON public.emergency_tokens FOR INSERT TO authenticated WITH CHECK(patient_id=auth.uid());
CREATE POLICY cb_tokens_upd ON public.emergency_tokens FOR UPDATE TO authenticated USING(patient_id=auth.uid()) WITH CHECK(patient_id=auth.uid());

-- Database-generated notifications, medicine-history entries, care-gap materialization, and audit history.
CREATE OR REPLACE FUNCTION public.cb_notify(p_id uuid,subject text,message text,kind text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE eid uuid:=gen_random_uuid(); ts text:=now()::text;
BEGIN
 IF p_id IS NULL THEN RETURN; END IF;
 INSERT INTO public.notifications(id,user_id,data)
 VALUES(eid,p_id,jsonb_build_object('id',eid,'userId',p_id,'title',subject,'message',message,'type',kind,'read',false,'createdAt',ts));
END;$$;
CREATE OR REPLACE FUNCTION public.cb_workflow() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE eid uuid; ts text:=now()::text; one_item jsonb;
BEGIN
 IF TG_OP='INSERT' THEN
  IF TG_TABLE_NAME='appointments' THEN PERFORM public.cb_notify(NEW.doctor_id,'New appointment',coalesce(NEW.data->>'reason','A patient requested an appointment'),'appointment'); END IF;
  IF TG_TABLE_NAME='prescriptions' THEN PERFORM public.cb_notify(NEW.patient_id,'New prescription',coalesce(NEW.data->>'medicine','A prescription was added'),'prescription'); END IF;
  IF TG_TABLE_NAME='lab_reports' THEN PERFORM public.cb_notify(NEW.patient_id,'Investigation requested',coalesce(NEW.data->>'testName','A test was requested'),'lab'); END IF;
  IF TG_TABLE_NAME='follow_ups' THEN PERFORM public.cb_notify(NEW.patient_id,'Follow-up scheduled',coalesce(NEW.data->>'reason','A follow-up was scheduled'),'followup'); END IF;
  IF TG_TABLE_NAME='blood_requests' THEN
   PERFORM public.cb_notify(u.id,'Matching blood request','A fictional request matches your blood group and city','blood')
   FROM public.users u WHERE u.role='donor' AND u.availability=true AND u.blood_group=NEW.data->>'bloodGroup' AND lower(u.city)=lower(NEW.data->>'city');
  END IF;
  IF TG_TABLE_NAME='medicine_orders' THEN
   PERFORM public.cb_notify(NEW.patient_id,'Pharmacy order created','Your demonstration order is processing','order');
   FOR one_item IN SELECT value FROM jsonb_array_elements(coalesce(NEW.data->'items','[]'::jsonb)) LOOP
    eid:=gen_random_uuid();
    INSERT INTO public.medicine_history(id,patient_id,data) VALUES(eid,NEW.patient_id,
     jsonb_build_object('id',eid,'patientId',NEW.patient_id,'orderId',NEW.id,'medicine',one_item->>'name','quantity',coalesce((one_item->>'quantity')::int,1),'status','processing','createdAt',ts));
   END LOOP;
  END IF;
 ELSE
  IF TG_TABLE_NAME='lab_reports' AND NEW.data->>'status'='completed' AND OLD.data->>'status' IS DISTINCT FROM 'completed' THEN
   PERFORM public.cb_notify(NEW.patient_id,'Investigation result available',coalesce(NEW.data->>'testName','Investigation')||' now has a result','lab');
  END IF;
  IF TG_TABLE_NAME='medicine_orders' AND NEW.data->>'status' IS DISTINCT FROM OLD.data->>'status' THEN
   UPDATE public.medicine_history SET data=jsonb_set(data,'{status}',to_jsonb(NEW.data->>'status')) WHERE data->>'orderId'=NEW.id::text;
   PERFORM public.cb_notify(NEW.patient_id,'Pharmacy order updated','Order status: '||coalesce(NEW.data->>'status','unknown'),'order');
  END IF;
  IF TG_TABLE_NAME='blood_requests' AND NEW.data->>'status' IS DISTINCT FROM OLD.data->>'status' THEN
   PERFORM public.cb_notify(NEW.patient_id,'Blood request status changed','Request status: '||NEW.data->>'status','blood');
  END IF;
 END IF;
 IF TG_TABLE_NAME NOT IN ('notifications','audit_logs','emergency_access_logs') THEN
  eid:=gen_random_uuid();
  INSERT INTO public.audit_logs(id,actor_id,data) VALUES(eid,auth.uid(),jsonb_build_object(
    'id',eid,'actorId',auth.uid(),'action',TG_OP||' '||TG_TABLE_NAME,
    'target',NEW.id,'detail','Database change','createdAt',ts));
 END IF;
 RETURN NEW;
END;$$;
DO $$DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY['appointments','prescriptions','lab_reports','follow_ups','blood_requests','medicine_orders','consents'] LOOP
 EXECUTE format('DROP TRIGGER IF EXISTS cb_workflow_trigger ON public.%I',t);
 EXECUTE format('CREATE TRIGGER cb_workflow_trigger AFTER INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.cb_workflow()',t);
END LOOP;END $$;

-- Accept request atomically. Restricts matches and prevents double acceptance.
CREATE OR REPLACE FUNCTION public.cb_accept_blood_request(request_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.blood_requests%ROWTYPE; d public.users%ROWTYPE; eid uuid; ts text:=now()::text;
BEGIN
 SELECT * INTO d FROM public.users WHERE id=auth.uid() AND role='donor' AND availability=true;
 IF NOT FOUND THEN RAISE EXCEPTION 'Donor not available'; END IF;
 SELECT * INTO r FROM public.blood_requests WHERE id=request_id FOR UPDATE;
 IF NOT FOUND OR r.data->>'status'<>'open' THEN RAISE EXCEPTION 'Request not available'; END IF;
 IF d.blood_group IS DISTINCT FROM r.data->>'bloodGroup' OR lower(coalesce(d.city,''))<>lower(coalesce(r.data->>'city','')) THEN RAISE EXCEPTION 'Not a matching request'; END IF;
 UPDATE public.blood_requests SET data=jsonb_set(jsonb_set(data,'{status}','"accepted"'::jsonb),'{acceptedBy}',to_jsonb(auth.uid()::text)) WHERE id=request_id;
 eid:=gen_random_uuid();
 INSERT INTO public.donation_history(id,donor_id,data) VALUES(eid,auth.uid(),jsonb_build_object('id',eid,'donorId',auth.uid(),'requestId',request_id,'status','accepted','createdAt',ts));
 RETURN true;
END;$$;
REVOKE ALL ON FUNCTION public.cb_accept_blood_request(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.cb_accept_blood_request(uuid) TO authenticated;

-- Default product catalog is fictional and for demonstrations; replace only with reviewed data.
INSERT INTO public.pharmacy_products(id,name,category,price,stock,description) VALUES
 ('a0000000-0000-4000-8000-000000000020','Sample Vitamin D','Supplements',120,50,'Demonstration catalog item; not medical advice'),
 ('a0000000-0000-4000-8000-000000000021','Sample Hydration Salts','Wellness',38,80,'Demonstration catalog item'),
 ('a0000000-0000-4000-8000-000000000022','Basic First Aid Kit','First Aid',240,35,'Demonstration catalog item'),
 ('a0000000-0000-4000-8000-000000000023','Digital Thermometer','Devices',320,25,'Demonstration catalog item')
ON CONFLICT(id) DO NOTHING;

-- Supabase Realtime publishes selected workflow tables (requires Realtime enabled in project).
DO $$ DECLARE t text; BEGIN FOREACH t IN ARRAY ARRAY[
 'users','appointments','consultations','prescriptions','medical_records','lab_reports','care_plans','follow_ups',
 'blood_requests','organ_donors','organ_requests','pharmacy_products','medicine_orders','medicine_history',
 'notifications','consents','audit_logs','family_members','emergency_profiles','donation_history'] LOOP
 BEGIN EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I',t);
 EXCEPTION WHEN duplicate_object THEN NULL; WHEN undefined_object THEN RAISE NOTICE 'Enable Realtime publication manually in Supabase'; END;
 END LOOP; END $$;

-- Private file storage; client paths must start with the patient UUID.
INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
VALUES('medical-records','medical-records',false,10485760,ARRAY['application/pdf','image/jpeg','image/png'])
ON CONFLICT(id) DO NOTHING;
CREATE POLICY cb_storage_read ON storage.objects FOR SELECT TO authenticated USING(
 bucket_id='medical-records' AND public.cb_can_read_patient((split_part(name,'/',1))::uuid));
CREATE POLICY cb_storage_upload ON storage.objects FOR INSERT TO authenticated WITH CHECK(
 bucket_id='medical-records' AND split_part(name,'/',1)=auth.uid()::text);
CREATE POLICY cb_storage_delete ON storage.objects FOR DELETE TO authenticated USING(
 bucket_id='medical-records' AND split_part(name,'/',1)=auth.uid()::text);

-- Explicit grants: PostgreSQL GRANT + RLS are both required (GRANT does not bypass RLS).
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO authenticated;
