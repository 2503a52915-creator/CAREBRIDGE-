# CAREBRIDGE backend — Supabase

The deployable backend in this project is **Supabase**, which hosts PostgreSQL, authentication, row-level security policies, storage, database event triggers, realtime subscriptions, and a Deno Edge Function for verifying emergency access.

1. Create a NEW Supabase project.
2. Run `../database/migrations/001_schema.sql` in SQL Editor.
3. Enable email authentication in Auth > Providers. Register patient and donor accounts through CAREBRIDGE. The database trigger automatically creates their `public.users` profile.
4. Copy Project URL and **anon/public key** into `frontend/.env` per `frontend/.env.example`.
5. Install the [Supabase CLI](https://supabase.com/docs/guides/local-development/cli/getting-started) if not already installed. From `backend`, run `supabase login`, `supabase link --project-ref YOUR_PROJECT_REF`, then `supabase functions deploy emergency-access --no-verify-jwt`.
6. Configure the Edge Function secret `CAREBRIDGE_ALLOWED_ORIGIN` to the exact HTTPS origin of your deployed frontend (e.g. `https://carebridge.example.com`). Supabase manages `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` for deployed functions; verify these exist in your project.
7. Optionally use Supabase Dashboard > Database > Replication to confirm tables are in `supabase_realtime` publication.

Doctor/admin accounts are **not** self-registerable (prevents self-assigning privileged roles). Create them manually in Supabase Auth, then promote the associated `public.users.role` in SQL Editor using a trusted project administrator. Never add service-role keys to frontend files or commit them.

The project has no standalone Express service: database policies and the Edge Function are the backend, kept entirely in this `backend/` folder and `database/` migrations. The frontend is a Vite single-page application. In demo mode, data resides ONLY in the browser and has no server-side security.

**Important:** This is an educational prototype, not a HIPAA/DPDP-compliant clinical system. Do not upload genuine health information or use it for actual patient care. Additional validation, formal privacy review, medical safety verification, backup, monitoring, and hardened authorization are needed before real deployment.
