// Supabase Edge Function — deploy with: supabase functions deploy emergency-access
// Request: POST { token: string, pin: string }
// Uses server-only SUPABASE_SERVICE_ROLE_KEY. Never expose service role to Vite.
import {serve} from 'https://deno.land/std@0.224.0/http/server.ts'
import {createClient} from 'https://esm.sh/@supabase/supabase-js@2'
const origin=Deno.env.get('CAREBRIDGE_ALLOWED_ORIGIN')||''
const cors={ 'Access-Control-Allow-Origin':origin||'null', 'Access-Control-Allow-Headers':'authorization,x-client-info,apikey,content-type', 'Access-Control-Allow-Methods':'POST,OPTIONS', 'Vary':'Origin'}
const respond=(body:object,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json'}})
const hex=async(value:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('')
serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors})
 if(req.method!=='POST')return respond({error:'Method not allowed'},405)
 if(!origin||req.headers.get('Origin')!==origin)return respond({error:'Origin not permitted'},403)
 try{
  const body=await req.json();const token=body?.token;const pin=body?.pin
  if(typeof token!=='string'||token.length>160||token.length<20||typeof pin!=='string'||!/^[0-9]{6}$/.test(pin))return respond({error:'Invalid verification data'},400)
  const url=Deno.env.get('SUPABASE_URL');const key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  if(!url||!key)return respond({error:'Service not configured'},503)
  const client=createClient(url,key,{auth:{persistSession:false}})
  const {data:row,error}=await client.from('emergency_tokens').select('id,patient_id,data').eq('data->>token',token).maybeSingle()
  if(error)throw error
  if(!row)return respond({error:'Invalid, revoked or expired link'},403)
  const attempts=Number(row.data?.attempts||0)
  if(row.data?.revoked||Date.parse(row.data?.expiresAt)<Date.now()||attempts>=5)return respond({error:'Invalid, revoked or expired link'},403)
  const isCorrect=await hex(pin)===row.data?.pinHash
  const {error:updateError}=await client.from('emergency_tokens').update({data:{...row.data,attempts:attempts+1}}).eq('id',row.id).eq('data->>attempts',String(attempts))
  if(updateError)throw updateError
  const logId=crypto.randomUUID()
  const {error:auditError}=await client.from('emergency_access_logs').insert({id:logId,patient_id:row.patient_id,data:{id:logId,patientId:row.patient_id,action:isCorrect?'verified':'denied',createdAt:new Date().toISOString()}})
  if(auditError)throw auditError
  if(!isCorrect)return respond({error:'Verification failed'},403)
  const {data:profile,error:profileError}=await client.from('emergency_profiles').select('data').eq('patient_id',row.patient_id).maybeSingle()
  if(profileError)throw profileError
  if(!profile)return respond({error:'No emergency profile exists'},404)
  return respond({bloodGroup:String(profile.data.bloodGroup||'Not documented'),allergies:String(profile.data.allergies||'Not documented'),emergencyContact:String(profile.data.emergencyContact||'Not documented'),emergencyPhone:String(profile.data.emergencyPhone||'Not documented')})
 }catch(error){console.error('Emergency verification error:',error);return respond({error:'Verification service unavailable'},503)}
})
