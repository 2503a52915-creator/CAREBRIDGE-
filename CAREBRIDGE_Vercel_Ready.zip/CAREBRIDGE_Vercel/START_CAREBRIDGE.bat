@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo    CAREBRIDGE - Local Educational Demo Launcher
echo =====================================================
echo.
where npm.cmd >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js / npm not detected.
  echo Install Node.js 20+ from https://nodejs.org/
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo Installing dependencies - requires internet...
  call npm.cmd install
  if errorlevel 1 (
    echo npm install failed. Check your internet access.
    pause
    exit /b 1
  )
)
echo Starting CAREBRIDGE at http://localhost:5173
call npm.cmd run dev
pause
