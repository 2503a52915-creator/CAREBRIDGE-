# CAREBRIDGE — Vercel + mobile deployment handoff

**Prepared 14 November 2026** · Intended academic demonstration period: **14 November–4 December 2026 (20 days)**.

This package is ready to import into a Vercel project. **No public Vercel URL is embedded here:** a live URL is issued only after an authenticated account actually deploys it. Never treat a made-up URL as a working deployment.

## Recommended: a stable production URL for your teacher

1. Use a computer with internet access and Node.js 20+.
2. Extract the ZIP. Open a terminal **inside the CAREBRIDGE_Vercel folder** (contains this file and root `vercel.json`).
3. Run `npx vercel login` and log in to your Vercel account.
4. Run `npx vercel --prod` and follow the project prompts. When asked for the project directory, use the current folder `./` (the root, **not** `frontend/`). The root `vercel.json` configures Vite, builds with `npm run build`, and publishes `frontend/dist`.
5. Copy the **production** `https://...vercel.app` URL printed at the end. Share that with your teacher. Do not share a localhost address or temporary deployment protection link.
6. Open the URL in a private browser tab on a **phone over mobile data**. Verify Home → Demo Role Login → Patient Dashboard → Appointments; switch role to Doctor and check prescription actions, and return to Patient. Check the phone navigation menu and refresh a nested route such as `/app/dashboard`.
7. To verify long-term accessibility, leave the Vercel project and team/account active, avoid exceeding plan quotas, and do not delete it or enable Deployment Protection for your teacher. Production URLs normally remain available; Vercel does **not** promise exactly 20 days of uninterrupted uptime on free hosting.

**Alternative browser-only route:** Create a GitHub repository containing the entire extracted folder, connect that repository from the Vercel dashboard → Add New → Project, choose **Root Directory `./`**, Framework **Vite**, Build Command `npm run build`, Output Directory `frontend/dist`, Install Command `npm install`, and deploy to **Production**. The same `vercel.json` already specifies these values. A Git-linked project can redeploy when you push changes.

## Environment mode and shared data

- **No Supabase credentials:** fully navigable *educational demo* with fictional records saved in **each browser's localStorage**. Works when opened on desktop and mobile, but each device starts with its own records. This is **not a real shared database or cross-device realtime**. Demo role buttons do not require passwords.
- **For synchronized cloud data:** create a Supabase project, run `database/migrations/001_schema.sql`, set `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` and `VITE_FORCE_DEMO=false` in Vercel **Project Settings → Environment Variables**, and **redeploy**. Configure authorized accounts, RLS and Edge Functions using `README.md` and `backend/README.md` before showing cloud workflows. Do not expose service-role keys or medical information. Supabase has its own availability and free-tier quotas/pausing policies; these are separate from Vercel.

## Mobile-ready changes in this ZIP

- Real viewport meta and responsive CSS layout across desktop, tablet and phone.
- Sidebar drawer/menu breakpoint fixed for widths between 768 and 870px.
- Small-screen toolbar and cards adjusted for narrow phone widths.
- App icon and web app manifest included. This is **not** a fully offline PWA because no service worker is installed.
- SPA route fallback configured so browser refresh on `/app/...` routes resolves correctly.

## Local verification and limitations

```bash
npm install
npm run lint
npm run test
npm run build
npm run dev
```

Offline syntax/schema checks pass in the packaging environment. Package installation, TypeScript typecheck, browser interaction and production build could **not** be run here because the npm package registry DNS was unavailable. Do not claim a live Vercel deployment or 20-day uptime without testing the actual production URL. Use fictional healthcare records only.

### Troubleshooting

- **404 on refresh:** confirm the root `vercel.json` is in the deployed root and the SPA rewrite is enabled.
- **Build error:** ensure the deployed root is the folder containing the root `package.json`; run `npm run build` locally and consult Vercel build logs.
- **Blank page:** check Developer Tools Console for errors and verify `frontend/dist/index.html` was generated.
- **Login says Supabase missing:** use **demo role login** or set up Supabase properly; real cloud login does not run without cloud credentials.
- **Different data on phone and laptop:** expected in localStorage demo mode; connect Supabase for shared data.
- **Link asks your teacher to sign into Vercel:** turn off Deployment Protection for the public demo production site in Vercel project settings (subject to your account's plan/settings).
